from .ComponentProps import ComponentProps


__all__ = [
    "ComponentProps",
]
